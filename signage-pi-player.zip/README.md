
# Signage Pi Player (Minimal)

Minimal HTML-based player for Raspberry Pi to test connectivity with the fake signage server.

## Usage
1. Open `index.html` in Chromium on the Pi (kiosk mode optional).
2. Configure server and device key in the browser console:
   - `localStorage.setItem('SERVER_URL', 'http://<server-ip>:3000');`
   - `localStorage.setItem('DEVICE_KEY', 'DEV-TEST');`
3. Reload to see playlist count.

Expected: "Playlist loaded: X items" if connection works.
