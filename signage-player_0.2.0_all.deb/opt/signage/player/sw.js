const CACHE = 'signage-cache-v1';
self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(clients.claim()); });
self.addEventListener('fetch', e => {
  e.respondWith((async()=> {
    try {
      const resp = await fetch(e.request);
      const c = await caches.open(CACHE);
      c.put(e.request, resp.clone());
      return resp;
    } catch {
      const cached = await caches.match(e.request);
      if (cached) return cached;
      return new Response('', {status: 504});
    }
  })());
});
